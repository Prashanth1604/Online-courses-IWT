from collections import UserString
from django.contrib import admin
from .models import users
admin.site.register(users)